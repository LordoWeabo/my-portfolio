module com.example.massa_app {
    requires java.sql;
    requires mysql.connector.j;
    requires javafx.controls;
    requires javafx.fxml;
    requires java.prefs;


    exports com.example.massa_app.controllers;
    opens com.example.massa_app.controllers to javafx.fxml;
    exports com.example.massa_app;
    opens com.example.massa_app to javafx.fxml;
}