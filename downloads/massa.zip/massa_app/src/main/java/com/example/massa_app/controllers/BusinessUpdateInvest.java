package com.example.massa_app.controllers;

import com.example.massa_app.utils.BusinessPreferences;
import com.example.massa_app.utils.DatabaseConnection;
import com.example.massa_app.utils.UserPreferences;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BusinessUpdateInvest {
    @FXML
    private GridPane gridContainer;

    @FXML
    public void initialize(){
        fetchData();
    }

    private void fetchData(){
        String query = "select * from business where business_owner_id = ?";

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement stmt = connection.prepareStatement(query);
        ) {
            int userId = UserPreferences.getUserId();

            stmt.setInt(1, userId);

            try (ResultSet rs = stmt.executeQuery()){
                int row = 0; // Indeks baris di GridPane
                int column = 0; // Indeks kolom di GridPane
                int maxColumns = 2; // Maksimum kolom per baris

                while (rs.next()){
                    int id = rs.getInt("business_id");
                    String name = rs.getString("business_name");
                    byte[] imageData = rs.getBytes("business_logo");

                    addBusinessCard(
                            id,
                            name,
                            id,
                            imageData,
                            column,
                            row
                    );

                    column++;
                    if (column  >= maxColumns){
                        column = 0;
                        row++;
                    }
                }
            }


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    private void addBusinessCard(int id,String title, int code, byte[] imagePath, int column, int row) {
        VBox card = new VBox();
        card.setSpacing(10);
        card.setAlignment(Pos.CENTER);
        card.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 15; -fx-padding: 10; -fx-border-color: #EEEEEE; -fx-border-radius: 15; -fx-effect: dropshadow(gaussian, #d3d3d3, 10, 0, 0, 5);");

        Image image = new Image(new ByteArrayInputStream(imagePath));
        // Gambar
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(250);
        imageView.setFitHeight(150);
        imageView.setPreserveRatio(true);

        card.setOnMouseClicked(event -> {
            BusinessPreferences.saveBusinessId(id);
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            try {
                SceneSwitcherController.switchScene(stage, "business-report-view.fxml", "List report");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        // Judul
        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");

        // Kode/Deskripsi
        Label codeLabel = new Label("#" + code);
        codeLabel.setStyle("-fx-text-fill: #9E9E9E; -fx-font-size: 12px;");

        card.getChildren().addAll(imageView, titleLabel, codeLabel);

        // Tambahkan ke GridPane
        gridContainer.add(card, column, row);
    }

    @FXML
    public void switchToDashboard(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "dashboad-view.fxml", "Dashboard");
    }

    @FXML
    public void swithToYourBusiness(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "your-business-view.fxml", "Your Business View");
    }

    @FXML
    public void switchProfile(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "profile-view.fxml", "Profile");
    }

    @FXML
    public void switchUpdateInvest(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "business-update-investor.fxml", "Profile");
    }

    @FXML
    public void switchBusinessInsight(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "business-insight-view.fxml", "Business Insight");
    }

    @FXML
    public void logout(ActionEvent event) throws IOException {
        UserPreferences.clearUserId();
        BusinessPreferences.clearBusinessId();
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "onboarding-view.fxml", "Onboarding");
    }
}
