package com.example.massa_app.controllers;

import com.example.massa_app.models.Investment;
import com.example.massa_app.utils.BusinessPreferences;
import com.example.massa_app.utils.DatabaseConnection;
import com.example.massa_app.utils.UserPreferences;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BusinessInsight {

    @FXML
    private VBox chartContainer;

    @FXML
    private TableView<Investment> tableView;
    @FXML
    private TableColumn<Investment, String> investorColumn;
    @FXML
    private TableColumn<Investment, String> dateColumn;
    @FXML
    private TableColumn<Investment, String> amountColumn;
    @FXML
    private TableColumn<Investment, String> contractColumn;
    @FXML
    private TableColumn<Investment, String> statusColumn;

    @FXML
    public void initialize() {
        BarChart<String, Number> barChart = createEngagementChart();
        // Ganti warna semua bar dengan satu warna
        barChart.lookupAll(".chart-bar").forEach(node -> node.setStyle("-fx-bar-fill: #3b82f6;")); // Warna biru

        chartContainer.getChildren().add(barChart);
        // Hubungkan kolom ke properti dari model
        investorColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getInvestor()));
        dateColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getDate()));
        amountColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getAmount()));
        contractColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getContract()));
        statusColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getStatus()));

        // Tambahkan event handler saat baris diklik
        tableView.setRowFactory(tv -> {
            TableRow<Investment> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (!row.isEmpty()) {
                    Investment rowData = row.getItem();
                    showUpdateStatusDialog(
                            Integer.toString(rowData.getIdInvestor()), // ID contoh, nanti ganti dengan data sesungguhnya
                            rowData.getInvestor(),
                            getNameBusiness(rowData.getIdBusiness()),
                            rowData.getAmount(),
                            rowData.getContract()
                    );
                }
            });
            return row;
        });

        fetchData();
    }

    private void fetchData() {
        String query = "select * from investment where bussinessowner_id = ?";

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement stmt = connection.prepareStatement(query);
        ) {
            int userId = UserPreferences.getUserId();

            stmt.setInt(1, userId);

            try (ResultSet rs = stmt.executeQuery()){
                // Tambahkan data ke tabel
                ObservableList<Investment> data = FXCollections.observableArrayList();
                while (rs.next()){
                    int id = rs.getInt("investment_id");
                    int idBusiness = rs.getInt("business_id");
                    String name = rs.getString("investment_name");
                    double amount = rs.getDouble("amount");
                    String date = rs.getString("created_at");
                    String status = rs.getString("status");
                  data.add(new Investment(id, idBusiness,name, date, "Rp "+ amount, "Contract Agreement - KTB", status));
                }

                tableView.setItems(data);

            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private String getNameBusiness(int business_id){
        String query = "select business_name from business where business_id = ?";
        String name = "";

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement stmt = connection.prepareStatement(query);
        ) {

            stmt.setInt(1, business_id);

            try (ResultSet rs = stmt.executeQuery()){
                while (rs.next()){
                    name = rs.getString("business_name");
                }

                return name;

            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Method untuk menampilkan dialog update status
    public void showUpdateStatusDialog(String id, String investor, String investmentFor, String amount, String contract) {
        // Buat dialog baru
        Dialog<String> dialog = new Dialog<>();
        dialog.setTitle("Update Investment Status");
        dialog.setHeaderText("Investment Details");

        // ButtonType untuk Reject dan Accept
        ButtonType rejectButtonType = new ButtonType("Reject", ButtonBar.ButtonData.CANCEL_CLOSE);
        ButtonType acceptButtonType = new ButtonType("Accept", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(rejectButtonType, acceptButtonType);

        // GridPane untuk konten dialog
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        // Tambahkan informasi data
        grid.add(new Label("Investor:"), 0, 0);
        grid.add(new Label(investor), 1, 0);

        grid.add(new Label("Investment For:"), 0, 1);
        grid.add(new Label(investmentFor), 1, 1);

        grid.add(new Label("Amount Of Investment:"), 0, 2);
        grid.add(new Label(amount), 1, 2);

        grid.add(new Label("Contract Agreement:"), 0, 3);
        Hyperlink contractLink = new Hyperlink(contract);
        grid.add(contractLink, 1, 3);

        dialog.getDialogPane().setContent(grid);

        // Handle tombol Accept dan Reject
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == acceptButtonType) {
                updateDatabaseStatus(id, "Accepted");
                return "Accepted";
            } else if (dialogButton == rejectButtonType) {
                updateDatabaseStatus(id, "Rejected");
                return "Rejected";
            }
            return null;
        });

        // Tampilkan dialog
        dialog.showAndWait().ifPresent(result -> {
            if (result.equals("Accepted")) {
                showAlert("Status Updated", "Investment has been accepted!");
            } else if (result.equals("Rejected")) {
                showAlert("Status Updated", "Investment has been rejected!");
            }
        });
    }

    // Method untuk update status ke database (dummy function)
    private void updateDatabaseStatus(String id, String status) {
        String query = "update investment set status = ? where investment_id = ?";

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement stmt = connection.prepareStatement(query);
        ){

            stmt.setString(1, status);
            stmt.setInt(2, Integer.parseInt(id));

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                fetchData();
            } else {
                showAlert("Not Found", "No data found with the given ID.");
            }



        } catch (SQLException e) {
            showAlert("Database Error", "Error: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    private BarChart<String, Number> createEngagementChart() {
        // Sumbu X (kategori bulan)
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("Month");

        // Sumbu Y (jumlah visitor)
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Total Visitor");

        // Membuat BarChart
        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
        ObservableList<XYChart.Data<String, Number>> chartData = fetchDataList();

        // Menambahkan data ke dalam chart
        XYChart.Series<String, Number> dataSeries = new XYChart.Series<>();
        dataSeries.setName("Total Visitor");
        dataSeries.getData().addAll(chartData);

        // Menambahkan data series ke dalam chart
        barChart.getData().add(dataSeries);


        return barChart;
    }

    public static ObservableList<XYChart.Data<String, Number>> fetchDataList() {
        String query = "SELECT month, visitors FROM engagement"; // Ganti dengan query Anda
        ObservableList<XYChart.Data<String, Number>> dataList = FXCollections.observableArrayList();

        try (Connection connection = DatabaseConnection.getConnection();  // Gunakan metode koneksi Anda
             PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String month = rs.getString("month");
                int visitors = rs.getInt("visitors");

                // Tambahkan data ke ObservableList
                dataList.add(new XYChart.Data<>(month, visitors));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return dataList;
    }



    // Method untuk menampilkan alert sederhana
    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }


    @FXML
    public void switchToDashboard(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "dashboad-view.fxml", "Dashboard");
    }

    @FXML
    public void swithToYourBusiness(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "your-business-view.fxml", "Your Business View");
    }

    @FXML
    public void switchProfile(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "profile-view.fxml", "Profile");
    }

    @FXML
    public void switchUpdateInvest(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "business-update-investor.fxml", "Profile");
    }

    @FXML
    public void switchBusinessInsight(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "business-insight-view.fxml", "Business Insight");
    }

    @FXML
    public void logout(ActionEvent event) throws IOException {
        UserPreferences.clearUserId();
        BusinessPreferences.clearBusinessId();
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "onboarding-view.fxml", "Onboarding");
    }
}
