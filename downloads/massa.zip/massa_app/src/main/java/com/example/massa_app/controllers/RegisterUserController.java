package com.example.massa_app.controllers;
import com.example.massa_app.utils.DatabaseConnection;
import com.example.massa_app.utils.UserPreferences;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;
import java.util.prefs.Preferences;

public class RegisterUserController {

//    private ObservableList<BussinessOwnerModel> boList;

    @FXML
    public void initialize(){

    }

    @FXML
    private TextField first_name;

    @FXML
    private TextField last_name;

    @FXML
    private DatePicker birth_of_day;

    @FXML
    private TextField email;

    @FXML
    private  TextField phone_number;

    @FXML
    private TextField npwp;

    @FXML
    private TextField password;

    @FXML
    private TextField password_confirmation;

    @FXML
    public void handleSubmit(ActionEvent event) {
        String valueFirstName = first_name.getText();
        String valueLastName = last_name.getText();
        LocalDate valueBirthOfDay = birth_of_day.getValue();
        String valueEmail = email.getText();
        String valuePhoneNumber = phone_number.getText();
        String valueNpwp = npwp.getText();
        String valuePassword = password.getText();
        String valuePasswordConfirmation = password_confirmation.getText();

        if (valueFirstName.isEmpty() || valueLastName.isEmpty() || valueEmail.isEmpty() || valuePhoneNumber.isEmpty() || valueNpwp.isEmpty() || valuePassword.isEmpty() || valuePasswordConfirmation.isEmpty()){
            errorAlert("Textfield does not be empty!");
            return;
        }

        if (!valuePassword.equals(valuePasswordConfirmation)){
            errorAlert("Password and PasswordConfirmation does not match!");
            return;
        }

        handleSendToDatabase(
                valueFirstName,
                valueLastName,
                valueBirthOfDay.toString(),
                valueEmail,
                valuePhoneNumber,
                Integer.parseInt(valueNpwp),
                valuePassword,
                event

        );
    }

    private void errorAlert(String messages) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error!");
        alert.setContentText(messages);
        alert.showAndWait();
    }

    private void handleSendToDatabase (
            String first_name,
            String last_name,
            String birth_of_day,
            String email,
            String phone_number,
            int npwp,
            String password,
            ActionEvent event
    ){
        String insertQuery = "INSERT INTO bussiness_owner (bo_first_name, bo_last_name, bo_birth_of_date, bo_phone_number, bo_email, npwp, password ) values (?,?,?,?,?,?,?)";
        String generateColumn = "bussinessowner_id";

        try(
                Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS)
                ) {
            stmt.setString(1, first_name);
            stmt.setString(2, last_name);
            stmt.setString(3, birth_of_day);
            stmt.setString(4, phone_number);
            stmt.setString(5, email);
            stmt.setInt(6, npwp);
            stmt.setString(7, password);

            int rowInserted = stmt.executeUpdate();

            if (rowInserted > 0) {
                // Ambil ID yang baru saja dibuat
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int userId = (int) generatedKeys.getLong(1);
                        // Simpan ID ke Preferences
                        UserPreferences.saveUserId(userId);

                        System.out.println("User registered successfully with ID: " + userId);

                        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
                        SceneSwitcherController.switchScene(stage, "register-bussiness.fxml", "Register Business");
                    } else {
                        System.out.println("Failed to retrieve generated ID.");
                    }
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }



        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    public void backButton(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "onboarding-view.fxml", "Onboarding");
    }
}
