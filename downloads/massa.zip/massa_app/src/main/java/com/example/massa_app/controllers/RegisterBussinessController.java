package com.example.massa_app.controllers;

import com.example.massa_app.utils.DatabaseConnection;
import com.example.massa_app.utils.UserPreferences;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.prefs.Preferences;

public class RegisterBussinessController {

    private Stage stage;

    private File selectedFile;
    byte[] fileData;

    @FXML
    private TextField name;

    @FXML
    private TextArea description;

    @FXML
    private TextField nib;

    @FXML
    private TextField industries;



    // Setter untuk stage (dapat dipanggil dari Main App)
    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    public  void handleFileUpload(ActionEvent event) throws IOException {
        FileChooser fileChooser = new FileChooser();

        selectedFile = fileChooser.showOpenDialog(stage);


        if (selectedFile != null) {
            System.out.println("File dipilih: " + selectedFile.getAbsolutePath());
            // Lakukan sesuatu dengan file (misalnya menyimpannya ke database)
            fileData = convertFileToByteArray(selectedFile);
        } else {
            System.out.println("Tidak ada file yang dipilih.");
        }

    }

    private byte[] convertFileToByteArray(File file) throws IOException {
        try (FileInputStream fis = new FileInputStream(file)) {
            return fis.readAllBytes();
        }
    }

    @FXML
    public void handleSubmit(ActionEvent event) throws IOException {

        String valueName = name.getText();
        String valueDescription = description.getText();
        String valueNIB = nib.getText();
        String valueIndustries = industries.getText();


        if (valueName.isEmpty() || valueDescription.isEmpty() || valueNIB.isEmpty() || valueIndustries.isEmpty() || this.fileData.length == 0 ){
            errorAlert("Textfield does not be empty!");
            return;
        }

        sendToDatabase(
                valueName,
                valueDescription,
                Integer.parseInt(valueNIB),
                valueIndustries,
                fileData,
                event
        );

    }

    private void sendToDatabase(
            String name,
            String desription,
            int nib,
            String industries,
            byte[] fileData,
            ActionEvent event
    ) {
        String insertQuery = "INSERT INTO business (business_owner_id, business_name, business_description, nib, industry, business_logo ) values (?,?,?,?,?,?)";
        try(
                Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(insertQuery)
                ){

            stmt.setInt(1, getUserIdFromPreferences());
            stmt.setString(2, name);
            stmt.setString(3, desription);
            stmt.setInt(4, nib);
            stmt.setString(5, industries);
            stmt.setBytes(6, fileData );

            int rowInserted = stmt.executeUpdate();

            if (rowInserted > 0){
                try {
                    Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
                    SceneSwitcherController.switchScene(stage, "dashboad-view.fxml", "Dashboard");
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            } else {
                errorAlert("Register failed!");
            }


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static int getUserIdFromPreferences() {
        return UserPreferences.getUserId();
    }

    private void errorAlert(String messages) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error!");
        alert.setContentText(messages);
        alert.showAndWait();
    }


}
