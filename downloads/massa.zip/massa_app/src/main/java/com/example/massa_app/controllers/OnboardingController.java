package com.example.massa_app.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class OnboardingController {

    @FXML
    protected  void  onCorporateClick(ActionEvent event)  throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "register-user-view.fxml", "Register");
    }

    @FXML
    protected void switchLogin(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "login-view.fxml", "Register");
    }


}