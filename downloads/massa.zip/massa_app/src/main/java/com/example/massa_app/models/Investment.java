package com.example.massa_app.models;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Investment {

    private final SimpleIntegerProperty idInvestor;
    private final SimpleIntegerProperty idBusiness;

    private final SimpleStringProperty investor;
    private final SimpleStringProperty date;
    private final SimpleStringProperty amount;
    private final SimpleStringProperty contract;
    private final SimpleStringProperty status;

    public Investment(int idInvestor, int idBusiness, String investor, String date, String amount, String contract, String status) {
        this.idInvestor = new SimpleIntegerProperty(idInvestor);
        this.idBusiness = new SimpleIntegerProperty(idBusiness);
        this.investor = new SimpleStringProperty(investor);
        this.date = new SimpleStringProperty(date);
        this.amount = new SimpleStringProperty(amount);
        this.contract = new SimpleStringProperty(contract);
        this.status = new SimpleStringProperty(status);
    }

    public int getIdInvestor() { return idInvestor.get(); }

    public int getIdBusiness() {return idBusiness.get();}

    public String getInvestor() { return investor.get(); }
    public String getDate() { return date.get(); }
    public String getAmount() { return amount.get(); }
    public String getContract() { return contract.get(); }
    public String getStatus() { return status.get(); }
}
