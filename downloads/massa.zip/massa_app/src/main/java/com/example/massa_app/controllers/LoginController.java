package com.example.massa_app.controllers;

import com.example.massa_app.utils.DatabaseConnection;
import com.example.massa_app.utils.UserPreferences;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.w3c.dom.Text;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginController {

    @FXML
    private TextField email;

    @FXML
    private TextField password;
    @FXML
    public void handleSubmit(ActionEvent event){
        if (email.getText().isEmpty() || password.getText().isEmpty()){
            showAlert(Alert.AlertType.ERROR, "Error", "Username and Passwrod must be filled!");
        }else {
            checkAuth(email.getText(), password.getText(), event);
        }
    }

    private void checkAuth(String email, String password, ActionEvent event) {
        // Query SQL untuk mengecek pengguna berdasarkan email dan password
        String query = "SELECT * FROM bussiness_owner WHERE bo_email = ? AND password = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            // Set parameter email dan password dalam query
            preparedStatement.setString(1, email);
            preparedStatement.setString(2, password);

            // Eksekusi query dan dapatkan hasilnya
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                // Jika hasil ditemukan, login berhasil
                int userId = resultSet.getInt("bussinessowner_id");
                UserPreferences.saveUserId(userId);

                Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
                SceneSwitcherController.switchScene(stage, "dashboad-view.fxml", "Dashboard");
            } else {
                // Jika tidak ditemukan, login gagal
                showAlert(Alert.AlertType.ERROR, "Login Failed", "Invalid email or password. Please try again.");
            }
        } catch (SQLException e) {
            // Jika terjadi error saat koneksi atau query
            showAlert(Alert.AlertType.ERROR, "Database Error", "An error occurred: " + e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.show();
    }

    @FXML
    public void backButton(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "onboarding-view.fxml", "Onboarding");
    }
}
