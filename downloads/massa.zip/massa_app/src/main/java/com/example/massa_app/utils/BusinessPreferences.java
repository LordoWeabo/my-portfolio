package com.example.massa_app.utils;

import java.util.prefs.Preferences;

public class BusinessPreferences {

    private static final String BUSINESS_ID_KEY = "businessId";
    private static final Preferences preferences = Preferences.userRoot().node("com.example.massa_app");


    public static void saveBusinessId(int userId) {
        preferences.putInt(BUSINESS_ID_KEY, userId);
    }

    public static int getBusinessId() {
        return preferences.getInt(BUSINESS_ID_KEY, -1); // Default value -1 jika tidak ditemukan
    }

    public static void clearBusinessId() {
        preferences.remove(BUSINESS_ID_KEY);
    }
}

