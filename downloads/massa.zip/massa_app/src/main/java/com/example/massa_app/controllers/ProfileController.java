package com.example.massa_app.controllers;

import com.example.massa_app.utils.BusinessPreferences;
import com.example.massa_app.utils.DatabaseConnection;
import com.example.massa_app.utils.UserPreferences;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.chrono.Chronology;

public class ProfileController {

    Stage stage;

    @FXML
    public void initialize() throws SQLException {
        fetchData();
    }

    @FXML
    private ImageView imageProfile;

    @FXML
    private TextField firstNameInput;

    @FXML
    private TextField lastNameInput;

    @FXML
    private TextField npwpInput;

    @FXML
    private DatePicker dateInput;

    @FXML
    private TextField emailInput;

    @FXML
    private TextField phoneInput;

    private File selectedFile;
    private byte[] fileData;



    private void fetchData() throws SQLException {

        String query = "select * from bussiness_owner where bussinessowner_id = ?";

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement stmt = connection.prepareStatement(query);
        ){
            int userId = UserPreferences.getUserId();
            stmt.setInt(1, userId);
            try(ResultSet rs = stmt.executeQuery()) {
                if (rs.next()){
                    String firstname = rs.getString("bo_first_name");
                    String lastname = rs.getString("bo_last_name");
                    String birth = rs.getString("bo_birth_of_date");
                    String phone = rs.getString("bo_phone_number");
                    String email = rs.getString("bo_email");
                    int npwp = rs.getInt("npwp");
                    byte[] fileData = rs.getBytes("bo_profile");

                    firstNameInput.setText(firstname);
                    lastNameInput.setText(lastname);
                    LocalDate date = LocalDate.parse(birth);
                    dateInput.setValue(date);
                    phoneInput.setText(phone);
                    emailInput.setText(email);
                    npwpInput.setText(Integer.toString(npwp));

                    if ((fileData != null && fileData.length > 0)) {
                        Image image = new Image(new ByteArrayInputStream(fileData));
                        imageProfile.setImage(image);
                    }



                }else {
                    System.out.println("Data tidak ditemukan untuk ID: " + userId);
                }
            }  catch (Exception e) {
                System.err.println("Terjadi kesalahan saat mengambil data: " + e.getMessage());
            }
        }
    }

    @FXML
    public  void handleFileUpload(MouseEvent event) throws IOException {
        FileChooser fileChooser = new FileChooser();

        selectedFile = fileChooser.showOpenDialog(stage);


        if (selectedFile != null) {
            System.out.println("File dipilih: " + selectedFile.getAbsolutePath());
            // Lakukan sesuatu dengan file (misalnya menyimpannya ke database)
            fileData = convertFileToByteArray(selectedFile);
            Image image = new Image(new ByteArrayInputStream(fileData));
            imageProfile.setImage(image);
        } else {
            System.out.println("Tidak ada file yang dipilih.");
        }

    }

    private byte[] convertFileToByteArray(File file) throws IOException {
        try (FileInputStream fis = new FileInputStream(file)) {
            return fis.readAllBytes();
        }
    }

    @FXML
    public void handleSave(){
        String valueFirstName = firstNameInput.getText();
        String valueLastName = lastNameInput.getText();
        LocalDate valueBirthOfDay = dateInput.getValue();
        String valueEmail = emailInput.getText();
        String valuePhoneNumber = phoneInput.getText();
        String valueNpwp = npwpInput.getText();

        SaveToDatabase(
                valueFirstName,
                valueLastName,
                valueBirthOfDay.toString(),
                valuePhoneNumber,
                valueEmail,
                Integer.parseInt(valueNpwp)
        );
    }

    private void SaveToDatabase(
            String firstname,
            String lastname,
            String date,
            String phone,
            String email,
            int npwp
    ){
        String query = "update bussiness_owner set bo_first_name = ?, bo_last_name = ?, bo_birth_of_date = ?, bo_phone_number = ?, bo_email = ?, npwp = ? where bussinessowner_id = ?";
        int userId = UserPreferences.getUserId();

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement stmt = connection.prepareStatement(query);
        ){

            stmt.setString(1,  firstname);
            stmt.setString(2,  lastname);
            stmt.setString(3,  date);
            stmt.setString(4,  phone);
            stmt.setString(5,  email);
            stmt.setInt(6, npwp);
            stmt.setInt(7, userId);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                if ((selectedFile != null && selectedFile.exists())) {
                    saveProfile();
                }
                showAlert(Alert.AlertType.INFORMATION, "Success", "Update successfully updated!");
                fetchData();
            } else {
                showAlert(Alert.AlertType.WARNING, "Not Found", "No data found with the given ID.");
            }



        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Error: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    private void saveProfile(){
        String query = "update bussiness_owner bo_profile = ? where bussinessowner_id = ?";
        int userId = UserPreferences.getUserId();

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement stmt = connection.prepareStatement(query);
        ){
            stmt.setBytes(1, fileData);
            stmt.setInt(2, userId);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                fetchData();
            } else {
                showAlert(Alert.AlertType.WARNING, "Not Found", "No data found with the given ID.");
            }



        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Error: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }
    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.show();
    }
    @FXML
    public void switchToDashboard(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "dashboad-view.fxml", "Dashboard");
    }

    @FXML
    public void swithToYourBusiness(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "your-business-view.fxml", "Your Business View");
    }

    @FXML
    public void switchProfile(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "profile-view.fxml", "Profile");
    }

    @FXML
    public void switchUpdateInvest(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "business-update-investor.fxml", "Profile");
    }

    @FXML
    public void logout(ActionEvent event) throws IOException {
        UserPreferences.clearUserId();
        BusinessPreferences.clearBusinessId();
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "onboarding-view.fxml", "Onboarding");
    }
}
