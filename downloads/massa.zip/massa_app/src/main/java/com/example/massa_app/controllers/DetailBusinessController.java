package com.example.massa_app.controllers;

import com.example.massa_app.utils.BusinessPreferences;
import com.example.massa_app.utils.DatabaseConnection;
import com.example.massa_app.utils.UserPreferences;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import org.w3c.dom.events.MouseEvent;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DetailBusinessController {

    Stage stage;

    @FXML
    ImageView logo_image;
    @FXML
    Text name;

    @FXML
    Label industries;

    @FXML
    TextField description;

    @FXML
    Label pitch_deck;

    @FXML
    Label supporting_file;

    @FXML
    Button investment;

    @FXML
    Label funding_needed;

    @FXML
    Label current_funding;

    private File selectedPitchDeck;
    private File selectedSupportingFile;

    Boolean status_invest;


    @FXML
    public void initialize(){
        fetchData();
    }


    private void fetchData(){
        String query = "select * from business where business_id = ?";

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement stmt = connection.prepareStatement(query);
        ){
            int userId = BusinessPreferences.getBusinessId();
            stmt.setInt(1, userId);
            try(ResultSet rs = stmt.executeQuery()) {
                if (rs.next()){
                    byte[] logo = rs.getBytes("business_logo");
                    String nameBusiness = rs.getString("business_name");
                    String industriesBusiness = rs.getString("industry");
                    String descriptionBusiness = rs.getString("business_description");
                    byte[] pitchDeckBusiness = rs.getBytes("video_pitch_deck");
                    byte[] businessProposal = rs.getBytes("business_proposal");
                    int investmentStatus = rs.getInt("invest_status");
                    int fundngCurrent = rs.getInt("funding_current");
                    int fundingNeeded = rs.getInt("funding_needed");

                    Image image = new Image( new ByteArrayInputStream(logo));

                    logo_image.setImage(image);

                    name.setText(nameBusiness);
                    industries.setText(industriesBusiness);
                    description.setText(descriptionBusiness);
                    pitch_deck.setText((pitchDeckBusiness != null && pitchDeckBusiness.length > 0)
                            ? "Pitch Deck Uploaded!"
                            : "Upload Pitch Deck!");
                    supporting_file.setText((businessProposal != null && businessProposal.length > 0)
                            ? "Proposal Uploaded!"
                            : "Upload Proposal!");
                    investment.setText((investmentStatus == 0)
                            ? "Open Investment Opportunity"
                            : "Close Investment Opportunity");

                    status_invest = investmentStatus != 0;

                    if (status_invest){
                        funding_needed.setText("Funding Needed : Rp " + fundingNeeded);
                        current_funding.setText("Current Funding : Rp " + (Math.max(fundngCurrent, 0)));
                    }else {
                        funding_needed.setVisible(false);
                        funding_needed.setManaged(false);
                        current_funding.setVisible(false);
                        current_funding.setManaged(false);
                    }



                    System.out.println(nameBusiness);
                }else {
                    System.out.println("Data tidak ditemukan untuk ID: " + userId);
                }
            }  catch (Exception e) {
                System.err.println("Terjadi kesalahan saat mengambil data: " + e.getMessage());
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    public  void handlePitchDeckUpload(javafx.scene.input.MouseEvent event) throws IOException {
        FileChooser fileChooser = new FileChooser();

        selectedPitchDeck = fileChooser.showOpenDialog(stage);


        if (selectedPitchDeck != null) {
            System.out.println("File dipilih: " + selectedPitchDeck.getAbsolutePath());
            pitch_deck.setText(selectedPitchDeck.getAbsolutePath());
            byte[] bytesFile = convertFileToByteArray(selectedPitchDeck);

            savePitchDeck(bytesFile);
        } else {
            System.out.println("Tidak ada file yang dipilih.");
        }
    }

    @FXML
    public  void handleSupportingFile(javafx.scene.input.MouseEvent event) throws IOException {
        FileChooser fileChooser = new FileChooser();

        selectedSupportingFile = fileChooser.showOpenDialog(stage);


        if (selectedSupportingFile != null) {
            System.out.println("File dipilih: " + selectedSupportingFile.getAbsolutePath());
            supporting_file.setText(selectedSupportingFile.getAbsolutePath());
            byte[] bytesFile = convertFileToByteArray(selectedSupportingFile);

            saveBusinessProposal(bytesFile);
        } else {
            System.out.println("Tidak ada file yang dipilih.");
        }
    }

    @FXML
    private void handleInvestClicked(){
        if (status_invest){
            saveCloseOpportunity();
        }else {
            showFundingDialog();
        }
    }

    private void showFundingDialog() {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("Funding Dialog");



        // **Labels and TextFields**
        Label fundingLabel = new Label("Funding Needed*");
        fundingLabel.setStyle("-fx-text-fill: #FFFFFF; -fx-font-weight: bold;");
        TextField fundingInput = new TextField();
        fundingInput.setPromptText("ex. Rp 1,000,000");

        Label purposeLabel = new Label("Funding Purpose*");
        purposeLabel.setStyle("-fx-text-fill: #FFFFFF; -fx-font-weight: bold;");
        TextField purposeInput = new TextField();
        purposeInput.setPromptText("ex: Development AI Technology");

        // **Buttons**
        Button cancelButton = new Button("Cancel");
        Button uploadButton = new Button("Upload");

        cancelButton.setOnAction(e -> dialog.close());
        uploadButton.setOnAction(e -> {
            if (fundingInput.getText().isEmpty() || purposeInput.getText().isEmpty()){
                showAlert(Alert.AlertType.ERROR, "Error!", "Textfield does not be empty!");
            }else {
                saveFundingOpportunity(Integer.parseInt(fundingInput.getText()), purposeInput.getText());
                dialog.close();
            }



        });

        // **Button Layout**
        HBox buttonLayout = new HBox(10, cancelButton, uploadButton);
        buttonLayout.setAlignment(Pos.CENTER);

        // **Grid Layout for Fields**
        GridPane gridPane = new GridPane();
        gridPane.setVgap(10);
        gridPane.setHgap(10);
        gridPane.setPadding(new Insets(20));
        gridPane.add(fundingLabel, 0, 0);
        gridPane.add(fundingInput, 0, 1);
        gridPane.add(purposeLabel, 0, 2);
        gridPane.add(purposeInput, 0, 3);
        fundingInput.setMaxWidth(Double.MAX_VALUE);
        purposeInput.setMaxWidth(Double.MAX_VALUE);
        GridPane.setHgrow(fundingInput, Priority.ALWAYS);
        GridPane.setHgrow(purposeInput, Priority.ALWAYS);

        // **Main Dialog Layout**
        VBox dialogLayout = new VBox(10, gridPane, buttonLayout);
        dialogLayout.setAlignment(Pos.CENTER);
        dialogLayout.setStyle("-fx-background-color: #002F6C; -fx-border-color: #00A1FF; -fx-border-width: 2;");
        dialogLayout.setPadding(new Insets(20));

        Scene dialogScene = new Scene(dialogLayout, 400, 250);
        dialog.setScene(dialogScene);
        dialog.showAndWait();
    }


    byte[] fileDataUpdate;

    @FXML
    public void showBusinessUpdateDialog() {
        // Membuat stage (dialog window)
        Stage dialogStage = new Stage();
        dialogStage.initModality(Modality.APPLICATION_MODAL);
        dialogStage.setTitle("Add Business");

        // Components
        Label businessNameLabel = new Label("Business Name*");
        TextField businessNameField = new TextField();
        businessNameField.setPromptText("Business Name");
        businessNameField.setText(name.getText());

        Label descriptionLabel = new Label("Business Description*");
        TextArea descriptionArea = new TextArea();
        descriptionArea.setPromptText("Description");
        descriptionArea.setText(description.getText());
        descriptionArea.setPrefRowCount(4);

        Label industryLabel = new Label("Type Of Industry*");
        TextField industryField = new TextField();
        industryField.setText(industries.getText());
        industryField.setPromptText("ex. Creative");

        Label logoLabel = new Label("Business Logo / Profile Picture");
        ImageView logoImageView = new ImageView();
        logoImageView.setFitWidth(100);
        logoImageView.setFitHeight(100);

        Button uploadButton = new Button("Upload Image");



        uploadButton.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Choose Image");
            fileChooser.getExtensionFilters().add(
                    new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")
            );
            File file = fileChooser.showOpenDialog(dialogStage);
            if (file != null) {
                Image image = new Image(file.toURI().toString());
                logoImageView.setImage(image);
                try {
                    fileDataUpdate = convertFileToByteArray(file);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        // Buttons for cancel and save
        Button cancelButton = new Button("Cancel");
        Button saveButton = new Button("Save");
        HBox buttonBox = new HBox(10, cancelButton, saveButton);
        buttonBox.setPadding(new Insets(10, 0, 0, 0));

        cancelButton.setOnAction(e -> dialogStage.close());
        saveButton.setOnAction(e -> {
            // Proses penyimpanan data
            String name = businessNameField.getText();
            String description = descriptionArea.getText();
            String industry = industryField.getText();

            saveUpdateBusiness(
                    name,
                    description,
                    industry
            );

            dialogStage.close();
        });

        // Layout
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.getChildren().addAll(
                businessNameLabel, businessNameField,
                descriptionLabel, descriptionArea,
                industryLabel, industryField,
                logoLabel, logoImageView, uploadButton,
                buttonBox
        );

        Scene scene = new Scene(root, 400, 500);
        dialogStage.setScene(scene);
        dialogStage.showAndWait();
    }



    private byte[] convertFileToByteArray(File file) throws IOException {
        try (FileInputStream fis = new FileInputStream(file)) {
            return fis.readAllBytes();
        }
    }

    private void saveUpdateBusiness(String name, String description, String industries){
        String query = "update business set business_name = ?, business_description = ?, industry = ? where business_id = ?";
        int BusinessId = BusinessPreferences.getBusinessId();

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement stmt = connection.prepareStatement(query);
        ){

            stmt.setString(1,name);
            stmt.setString(2,description);
            stmt.setString(3,industries);
            stmt.setInt(4, BusinessId);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                if (fileDataUpdate != null && fileDataUpdate.length > 0){
                    saveLogoBusiness();
                }
                showAlert(Alert.AlertType.INFORMATION, "Success", "Business successfully updated!");
                fetchData();
            } else {
                showAlert(Alert.AlertType.WARNING, "Not Found", "No data found with the given ID.");
            }



        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Error: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    private void saveLogoBusiness(){
        String query = "update business set business_logo = ? where business_id = ?";
        int BusinessId = BusinessPreferences.getBusinessId();

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement stmt = connection.prepareStatement(query);
        ){

            stmt.setBytes(1,fileDataUpdate);
            stmt.setInt(2, BusinessId);

            int rowsAffected = stmt.executeUpdate();

        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Error: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    private void savePitchDeck(byte[] fileData){
        String query = "update business set video_pitch_deck = ? where business_id = ?";
        int BusinessId = BusinessPreferences.getBusinessId();

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement stmt = connection.prepareStatement(query);
        ){

            stmt.setBytes(1,fileData);
            stmt.setInt(2, BusinessId);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Pitch Deck successfully updated!");
            } else {
                showAlert(Alert.AlertType.WARNING, "Not Found", "No data found with the given ID.");
            }



        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Error: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    private void saveBusinessProposal(byte[] fileData){
        String query = "update business set business_proposal = ? where business_id = ?";
        int BusinessId = BusinessPreferences.getBusinessId();

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement stmt = connection.prepareStatement(query);
        ){

            stmt.setBytes(1,fileData);
            stmt.setInt(2, BusinessId);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Supporting File successfully updated!");
            } else {
                showAlert(Alert.AlertType.WARNING, "Not Found", "No data found with the given ID.");
            }



        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Error: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    public void saveFundingOpportunity(int fundingNeeded, String fundingPropose){
        String query = "update business set funding_propose = ?, funding_needed = ?, invest_status = 1 where business_id = ?";
        int BusinessId = BusinessPreferences.getBusinessId();

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement stmt = connection.prepareStatement(query);
        ){

            stmt.setString(1,fundingPropose);
            stmt.setInt(2, fundingNeeded);
            stmt.setInt(3, BusinessId);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Update successfully updated!");
                fetchData();
            } else {
                showAlert(Alert.AlertType.WARNING, "Not Found", "No data found with the given ID.");
            }



        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Error: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    private void saveCloseOpportunity(){
        String query = "update business set invest_status = 0 where business_id = ?";
        int BusinessId = BusinessPreferences.getBusinessId();

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement stmt = connection.prepareStatement(query);
        ){

            stmt.setInt(1, BusinessId);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Update successfully updated!");
                fetchData();
            } else {
                showAlert(Alert.AlertType.WARNING, "Not Found", "No data found with the given ID.");
            }



        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Error: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.show();
    }

    @FXML
    public void switchToDashboard(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "dashboad-view.fxml", "Dashboard");
    }

    @FXML
    public void swithToYourBusiness(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "your-business-view.fxml", "Your Business View");
    }

    @FXML
    public void switchProfile(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "profile-view.fxml", "Profile");
    }

    @FXML
    public void switchUpdateInvest(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "business-update-investor.fxml", "Profile");
    }

    @FXML
    public void switchBusinessInsight(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "business-insight-view.fxml", "Business Insight");
    }

    @FXML
    public void logout(ActionEvent event) throws IOException {
        UserPreferences.clearUserId();
        BusinessPreferences.clearBusinessId();
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "onboarding-view.fxml", "Onboarding");
    }



}
