package com.example.massa_app.controllers;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class SceneSwitcherController {
    public  static void switchScene(Stage stage, String fxmlPath, String title) throws IOException {
        FXMLLoader loader = new FXMLLoader(SceneSwitcherController.class.getResource("/com/example/massa_app/views/" + fxmlPath));
        Parent root = loader.load();
        Scene scene = new Scene(root, 787.0, 586.0);
        stage.setTitle(title);
        stage.setScene(scene);
        stage.show();
    }
}
