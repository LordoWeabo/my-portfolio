package com.example.massa_app;

import com.example.massa_app.utils.UserPreferences;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class OnboardingApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        int userId = UserPreferences.getUserId();
        String resource = (userId > 0) ? "views/dashboad-view.fxml" : "views/onboarding-view.fxml";
        FXMLLoader fxmlLoader = new FXMLLoader(OnboardingApplication.class.getResource(resource));
        Scene scene = new Scene(fxmlLoader.load(), 787.0, 586.0);
        stage.setTitle("Onboading!");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}