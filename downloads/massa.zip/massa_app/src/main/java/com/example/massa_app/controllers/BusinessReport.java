package com.example.massa_app.controllers;

import com.example.massa_app.utils.BusinessPreferences;
import com.example.massa_app.utils.DatabaseConnection;
import com.example.massa_app.utils.UserPreferences;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;
import java.util.Optional;

public class BusinessReport {

    Stage stage;

    @FXML
    private VBox listContainer;

    @FXML
    private TextField searchField;

    @FXML
    private Text businessName;

    private File selectedFile;
    private byte[] fileData;
    private  Label uploadHint;

    @FXML
    public void initialize(){
        fetchDataBusiness();
        fetchDataReport();
    }

    private void fetchDataBusiness(){
        String query = "select * from business where business_id = ?";

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement stmt = connection.prepareStatement(query);
        ) {
            int busisnessId = BusinessPreferences.getBusinessId();

            stmt.setInt(1, busisnessId);

            try (ResultSet rs = stmt.executeQuery()){
                if (rs.next()){
                    String nameBusiness = rs.getString("business_name");
                    businessName.setText(nameBusiness);
                    System.out.println(nameBusiness);
                }else {
                    System.out.println("Data tidak ditemukan untuk ID: " + busisnessId);
                }
            }


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private void fetchDataReport(){
        String query = "select * from report where business_id = ?";

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement stmt = connection.prepareStatement(query);
        ) {
            int busisnessId = BusinessPreferences.getBusinessId();

            stmt.setInt(1, busisnessId);

            try (ResultSet rs = stmt.executeQuery()){
                while (rs.next()){
                    int idReport = rs.getInt("report_id");
                    String name = rs.getString("title_report");
                    String created_at = rs.getString("created_at");

                    addReportItem(idReport, name, created_at);
                }
            }


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private void addReportItem(int idReport, String title, String date) {
        // HBox untuk item laporan
        HBox item = new HBox(20);
        item.setStyle("-fx-border-color: #ddd; -fx-border-radius: 10; -fx-padding: 10; -fx-background-color: #fff;");
        item.setAlignment(javafx.geometry.Pos.CENTER_LEFT);

        // Icon (simulasi dengan teks)
        Text icon = new Text("📄");
        icon.setStyle("-fx-font-size: 28;");

        // Informasi laporan
        VBox info = new VBox();
        Text titleText = new Text(title);
        titleText.setStyle("-fx-font-weight: bold;");
        Text dateText = new Text("Created at: " + date);
        dateText.setStyle("-fx-font-size: 12;");
        info.getChildren().addAll(titleText, dateText);


        Button deleteButton = new Button("Delete");
        deleteButton.setStyle("-fx-background-color: #002E6D; -fx-text-fill: white; -fx-border-radius: 20;");
        deleteButton.setOnAction(event -> {
            boolean confirmed = showConfirmationAlert("Delete Report", "Are you sure you want to delete this report?");
            if (confirmed) {
                boolean isDeleted = deleteReport(idReport);
                if (isDeleted) {
                    // Hapus dari tampilan jika berhasil
                    listContainer.getChildren().remove(item);
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Report deleted successfully!");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to delete report.");
                }
            } else {
                // Jika pengguna memilih Cancel
                showAlert(Alert.AlertType.INFORMATION, "Canceled", "Delete operation was canceled.");
            }
        });

        // Spacer agar tombol pindah ke pojok kanan
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // Add semua elemen ke item
        item.getChildren().addAll(icon, info, spacer, deleteButton);

        // Tambahkan item ke container
        listContainer.getChildren().add(item);
    }

    @FXML
    public void showUploadDialog() {
        // Membuat Stage untuk dialog
        Stage dialogStage = new Stage();
        dialogStage.initModality(Modality.APPLICATION_MODAL);
        dialogStage.setTitle("Upload File");

        // VBox Utama
        VBox root = new VBox(20);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: white; -fx-background-radius: 10;");

        // Tombol Back
        HBox topBar = new HBox();
        Button backButton = new Button("←");
        backButton.setStyle("-fx-background-radius: 50%; -fx-background-color: transparent; -fx-font-size: 18;");
        topBar.getChildren().add(backButton);
        root.getChildren().add(topBar);

        // GridPane untuk form
        GridPane gridPane = new GridPane();
        gridPane.setHgap(10);
        gridPane.setVgap(20);
        gridPane.setAlignment(Pos.CENTER_LEFT);

        // File Name Input
        Label fileNameLabel = new Label("File Name:");
        fileNameLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14;");
        TextField fileNameField = new TextField();
        fileNameField.setPromptText("ex. Laporan Finansial 2024");
        fileNameField.setStyle("-fx-background-radius: 10;");
        gridPane.addRow(0, fileNameLabel, fileNameField);

        // Upload Document
        Label uploadLabel = new Label("Upload Document:");
        uploadLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14;");
        VBox uploadBox = new VBox(10);
        uploadBox.setAlignment(Pos.CENTER);
        uploadBox.setStyle("-fx-border-color: #ddd; -fx-border-radius: 10; -fx-padding: 15;");
        Button uploadButton = new Button("📄");
        uploadButton.setStyle("-fx-background-color: transparent; -fx-font-size: 18;");
        uploadButton.setOnAction(event -> {
            try {
                handleFileUpload();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        uploadHint = new Label("Upload your file");
        uploadHint.setStyle("-fx-text-fill: gray; -fx-font-size: 12;");
        uploadBox.getChildren().addAll(uploadButton, uploadHint);
        gridPane.addRow(1, uploadLabel, uploadBox);

        root.getChildren().add(gridPane);

        // Tombol Upload
        Button submitButton = new Button("Upload");
        submitButton.setStyle(
                "-fx-background-color: #002E6D; -fx-text-fill: white; -fx-font-size: 14; -fx-background-radius: 10;");
        submitButton.setPrefWidth(150);
        VBox.setMargin(submitButton, new Insets(10, 0, 0, 0));
        root.setAlignment(Pos.CENTER);
        root.getChildren().add(submitButton);

        // Event Handler tombol Upload
        submitButton.setOnAction(e -> {
            String fileName = fileNameField.getText();
            if (fileName.isEmpty() || (selectedFile == null && !selectedFile.exists())){
                showAlert(Alert.AlertType.ERROR, "Error!", "Text field must be filled!");
            }else {
                handleSubmit(fileName);
                dialogStage.close();
            }


        });

        // Scene dan Stage
        Scene scene = new Scene(root, 400, 300);
        dialogStage.setScene(scene);
        dialogStage.showAndWait();
    }

    public  void handleFileUpload() throws IOException {
        FileChooser fileChooser = new FileChooser();

        selectedFile = fileChooser.showOpenDialog(stage);


        if (selectedFile != null) {
            System.out.println("File dipilih: " + selectedFile.getAbsolutePath());
            uploadHint.setText(selectedFile.getAbsolutePath());
            fileData = convertFileToByteArray(selectedFile);
        } else {
            System.out.println("Tidak ada file yang dipilih.");
        }
    }

    private byte[] convertFileToByteArray(File file) throws IOException {
        try (FileInputStream fis = new FileInputStream(file)) {
            return fis.readAllBytes();
        }
    }

    private void handleSubmit(
          String  title
    ){
        String query = "insert into report (business_id, title_report, file_report, created_at) values (?,?,?,?)";
        int businessId = BusinessPreferences.getBusinessId();

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement stmt = connection.prepareStatement(query);
        ){
            stmt.setInt(1, businessId);
            stmt.setString(2, title);
            stmt.setBytes(3, fileData);
            LocalDate date = LocalDate.now();
            stmt.setString(4, date.toString());

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                fetchDataReport();
            } else {
                showAlert(Alert.AlertType.WARNING, "Not Found", "No data found with the given ID.");
            }



        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Error: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    private boolean deleteReport(int id) {
        String query = "DELETE FROM report WHERE report_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, id);
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0; // Return true jika sukses
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.show();
    }

    // Fungsi untuk menampilkan alert konfirmasi
    private boolean showConfirmationAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(title);
        alert.setContentText(content);

        Optional<ButtonType> result = alert.showAndWait();
        return result.isPresent() && result.get() == ButtonType.OK;
    }

    @FXML
    public void switchToDashboard(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "dashboad-view.fxml", "Dashboard");
    }

    @FXML
    public void swithToYourBusiness(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "your-business-view.fxml", "Your Business View");
    }

    @FXML
    public void switchProfile(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "profile-view.fxml", "Profile");
    }

    @FXML
    public void switchUpdateInvest(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "business-update-investor.fxml", "Profile");
    }

    @FXML
    public void switchBusinessInsight(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "business-insight-view.fxml", "Business Insight");
    }

    @FXML
    public void logout(ActionEvent event) throws IOException {
        UserPreferences.clearUserId();
        BusinessPreferences.clearBusinessId();
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        SceneSwitcherController.switchScene(stage, "onboarding-view.fxml", "Onboarding");
    }
}
