package com.example.massa_app.utils;

import java.util.prefs.Preferences;

public class UserPreferences {

    private static final String USER_ID_KEY = "userId";
    private static final Preferences preferences = Preferences.userRoot().node("com.example.massa_app");

    // Method untuk menyimpan User ID ke Preferences
    public static void saveUserId(int userId) {
        preferences.putInt(USER_ID_KEY, userId);
    }

    // Method untuk mengambil User ID dari Preferences
    public static int getUserId() {
        return preferences.getInt(USER_ID_KEY, -1); // Default value -1 jika tidak ditemukan
    }

    // (Opsional) Method untuk menghapus User ID dari Preferences
    public static void clearUserId() {
        preferences.remove(USER_ID_KEY);
    }
}
