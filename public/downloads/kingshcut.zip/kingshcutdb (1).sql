-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 19, 2024 at 07:31 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kingshcutdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `msservice`
--

CREATE TABLE `msservice` (
  `ServiceID` varchar(10) NOT NULL,
  `ServiceName` varchar(50) NOT NULL,
  `Price` int(11) NOT NULL,
  `ServiceTypeID` varchar(10) DEFAULT NULL,
  `Duration` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `msservice`
--

INSERT INTO `msservice` (`ServiceID`, `ServiceName`, `Price`, `ServiceTypeID`, `Duration`) VALUES
('SV002', 'Down Perm', 175000, 'ST002', 90),
('SV003', 'Korean Perm', 400000, 'ST002', 90),
('SV004', 'perm kribo', 100000, 'ST001', 120);

-- --------------------------------------------------------

--
-- Table structure for table `msservicetype`
--

CREATE TABLE `msservicetype` (
  `ServiceTypeID` varchar(10) NOT NULL,
  `ServiceTypeName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `msservicetype`
--

INSERT INTO `msservicetype` (`ServiceTypeID`, `ServiceTypeName`) VALUES
('ST001', 'Haircut'),
('ST002', 'Perm'),
('ST003', 'Coloring'),
('ST004', 'Treatment'),
('ST005', 'Styling');

-- --------------------------------------------------------

--
-- Table structure for table `msuser`
--

CREATE TABLE `msuser` (
  `UserID` varchar(10) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `UserEmail` varchar(50) NOT NULL,
  `Role` enum('Admin','User') NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `UserPhoneNumber` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `msuser`
--

INSERT INTO `msuser` (`UserID`, `Username`, `Password`, `UserEmail`, `Role`, `Gender`, `UserPhoneNumber`) VALUES
('US261', 'admin', 'admin123', 'admin@gmail.com', 'Admin', 'Male', '0856123321'),
('US515', 'aldoo', 'aldo1234', 'aldo@gmail.com', 'User', 'Male', '0851569889669'),
('US902', 'jepri', 'jepri123', 'jepri@gmail.com', 'User', 'Male', '0852182319821'),
('US981', 'jovan', 'jovan123', 'jovan@gmail.com', 'User', 'Male', '0895368570703');

-- --------------------------------------------------------

--
-- Table structure for table `reservationdetail`
--

CREATE TABLE `reservationdetail` (
  `DetailID` varchar(10) NOT NULL,
  `ReservationID` varchar(10) DEFAULT NULL,
  `ServiceID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservationdetail`
--

INSERT INTO `reservationdetail` (`DetailID`, `ReservationID`, `ServiceID`) VALUES
('RS005-D001', 'RS005', 'SV002'),
('RS006-D001', 'RS006', 'SV002'),
('RS006-D002', 'RS006', 'SV003'),
('RS007-D001', 'RS007', 'SV003');

-- --------------------------------------------------------

--
-- Table structure for table `reservationheader`
--

CREATE TABLE `reservationheader` (
  `ReservationID` varchar(10) NOT NULL,
  `UserID` varchar(10) DEFAULT NULL,
  `ReservationDate` date NOT NULL,
  `ReservationTime` time NOT NULL,
  `Status` varchar(20) DEFAULT 'In Progress'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservationheader`
--

INSERT INTO `reservationheader` (`ReservationID`, `UserID`, `ReservationDate`, `ReservationTime`, `Status`) VALUES
('RS001', NULL, '2024-01-19', '14:30:00', 'Finished'),
('RS002', NULL, '2024-01-20', '16:00:00', 'Finished'),
('RS003', NULL, '2024-01-21', '12:00:00', 'Cancelled'),
('RS004', 'US981', '2024-12-19', '15:00:00', 'Finished'),
('RS005', 'US981', '2024-12-19', '15:00:00', 'Cancelled'),
('RS006', 'US981', '2024-12-25', '00:00:50', 'In Progress'),
('RS007', 'US981', '2024-12-26', '00:00:50', 'In Progress');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `msservice`
--
ALTER TABLE `msservice`
  ADD PRIMARY KEY (`ServiceID`),
  ADD KEY `ServiceTypeID` (`ServiceTypeID`);

--
-- Indexes for table `msservicetype`
--
ALTER TABLE `msservicetype`
  ADD PRIMARY KEY (`ServiceTypeID`);

--
-- Indexes for table `msuser`
--
ALTER TABLE `msuser`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Username` (`Username`),
  ADD UNIQUE KEY `UserEmail` (`UserEmail`),
  ADD UNIQUE KEY `UserPhoneNumber` (`UserPhoneNumber`);

--
-- Indexes for table `reservationdetail`
--
ALTER TABLE `reservationdetail`
  ADD PRIMARY KEY (`DetailID`),
  ADD KEY `ReservationID` (`ReservationID`),
  ADD KEY `ServiceID` (`ServiceID`);

--
-- Indexes for table `reservationheader`
--
ALTER TABLE `reservationheader`
  ADD PRIMARY KEY (`ReservationID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `msservice`
--
ALTER TABLE `msservice`
  ADD CONSTRAINT `msservice_ibfk_1` FOREIGN KEY (`ServiceTypeID`) REFERENCES `msservicetype` (`ServiceTypeID`);

--
-- Constraints for table `reservationdetail`
--
ALTER TABLE `reservationdetail`
  ADD CONSTRAINT `reservationdetail_ibfk_1` FOREIGN KEY (`ReservationID`) REFERENCES `reservationheader` (`ReservationID`) ON DELETE CASCADE,
  ADD CONSTRAINT `reservationdetail_ibfk_2` FOREIGN KEY (`ServiceID`) REFERENCES `msservice` (`ServiceID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
